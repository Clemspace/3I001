import java.util.Random;


public class Client implements Runnable{

	private static int cpt = 0;
	public final int id;
	private Random gen = new Random();
	private int nbRequetes;
	private Serveur serv;
	private Condition attendReponse= new Condition();


	public Client(int nb, Serveur serveur){// sinon definir type dans une methode de la classe serveur
		
		id = ++cpt;
		nbRequetes = nb;
		serv = serveur;

	}

	public void requeteServie(ReponseRequete r){
		
		System.out.println(r.toString);
		attendReponse.signal();
		
	}

	public void run(){

		for(int i = 1; i <= nbRequetes ; i++){
			try{
			s.soumettre(id, i);
			}catch(InterruptedException e){
				System.out.println("Client en famine!");
			}	
		}

	}
}
