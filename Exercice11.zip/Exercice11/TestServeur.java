
public class TestServeur{

	public static void main(String[] args){

		public final int NB_CLIENTS = 6;
		public final int NB_REQUETES = 5;

		public Thread serveur = new Thread(new Serveur(clients));
		public Thread[] clients = new Thread[NB_CLIENTS];


		for(int i = 0;i<NB_CLIENTS;i++){
			clients[i]  = new Thread(new Client(NB_REQUETES));
			i.start();

		}

		for(int i = 0;i<NB_CLIENTS;i++){
			i.join();

		}
		serveur.interrupt();

	}
}
